
  # Premium Quiz Page UI Design

  This is a code bundle for Premium Quiz Page UI Design. The original project is available at https://www.figma.com/design/qeUMzRNlz9YyWmqgvnp0N9/Premium-Quiz-Page-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  